import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.neuroph.core.NeuralNetwork;
import org.neuroph.imgrec.ImageRecognitionPlugin;

public class Network {

 public static void main(String[] args) {
    // load trained neural network saved with Neuroph Studio (specify some existing neural network file here)
    NeuralNetwork gaze = NeuralNetwork.load("lib/networks/Gaze.nnet"); // load trained neural network saved with Neuroph Studio
    NeuralNetwork eye = NeuralNetwork.load("lib/networks/Eye.nnet");
    long start;
    long end;
    // get the image recognition plugin from neural network
    ImageRecognitionPlugin gazeImageRecognition = (ImageRecognitionPlugin)gaze.getPlugin(ImageRecognitionPlugin.class); // get the image recognition plugin from neural network
    ImageRecognitionPlugin eyeImageRecognition = (ImageRecognitionPlugin)eye.getPlugin(ImageRecognitionPlugin.class);    
    try {
    	File dir = new File("lib/images/LowerLeft/LeftEye/");
    	FileWriter fstream = new FileWriter("lib/log.txt");
    	BufferedWriter out = new BufferedWriter(fstream);
    	for (File file : dir.listFiles()) {
    		// image recognition is done here (specify some existing image file)	
    		Calendar gazeStart = Calendar.getInstance();
    		HashMap<String, Double> gazeOutput = gazeImageRecognition.recognizeImage(file);
    	    Calendar gazeEnd = Calendar.getInstance();
    	    start = gazeStart.getTimeInMillis();
    		end = gazeEnd.getTimeInMillis();
    		out.write("---------------------" + file.getName() + "-----------------------" + System.getProperty("line.separator"));
    		out.write("gaze output: " + gazeOutput.toString() + System.getProperty("line.separator"));
    		out.write("start time(ms):" + start + System.getProperty("line.separator"));
    		out.write("end time(ms): " + end + System.getProperty("line.separator"));
    		out.write(System.getProperty("line.separator"));
//    		System.out.println("file: " + file.getName());
//    		System.out.println("output: " + gazeOutput.toString());
//    		System.out.println("start time(ms):" + start);
//    		System.out.println("end time(ms): " + end);
//    		System.out.println();
    		
    		Calendar eyeStart = Calendar.getInstance();
    		HashMap<String, Double> eyeOutput = eyeImageRecognition.recognizeImage(file);
    		Calendar eyeEnd = Calendar.getInstance();
    		start = eyeStart.getTimeInMillis();
    		end = eyeEnd.getTimeInMillis();
    		out.write("eye output: " + eyeOutput.toString() + System.getProperty("line.separator"));
    		out.write("start time(ms):" + start + System.getProperty("line.separator"));
    		out.write("end time(ms):" + end + System.getProperty("line.separator"));
    		out.write(System.getProperty("line.separator"));
//    		System.out.println("file: " + file.getName());
//    		System.out.println("output: " + eyeOutput.toString());
//    		System.out.println("start time(ms):" + start);
//    		System.out.println("end time(ms):" + end);
//    		System.out.println();
    	}
    	out.close();

    } catch(IOException ioe) {
        ioe.printStackTrace();
    }
 }
}
